'use strict';

module.exports = require('./route.js')