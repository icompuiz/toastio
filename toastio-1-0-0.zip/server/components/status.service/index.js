'use strict';
module.exports = {
	session: {},
	initializing: false
};