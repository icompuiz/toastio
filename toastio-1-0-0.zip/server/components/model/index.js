'use strict';

module.exports = require('./base.model');