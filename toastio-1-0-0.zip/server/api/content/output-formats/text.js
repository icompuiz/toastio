
function printProperty(property) {

	return property.value;

}

module.exports = {
	print: printProperty
};