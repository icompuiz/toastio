module.exports = [
	{ name: 'SYSTEM', system: true },
	{ name: 'administrators', system: true },
	{ name: 'public', system: true },
	{ name: 'users', system: true },
];